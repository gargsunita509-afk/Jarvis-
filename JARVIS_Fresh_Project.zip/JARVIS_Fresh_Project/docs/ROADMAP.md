# Recommended next development phases

1. **Test the current overlay** on the target Android phone and fix OEM-specific behaviour.
2. Replace demo chat responses with a secure AI backend. Keep API credentials server-side.
3. Add Firebase Authentication and Firestore sync with strict ownership rules.
4. Add a push-to-talk Android voice flow with explicit microphone permission and visible foreground notification.
5. Evaluate an on-device wake-word engine with suitable licensing, battery tests, and Android microphone foreground-service compliance.
6. Connect wake-word detection to the large overlay; test false activations, lock screen, battery saver, and app switching.
7. Add an allow-listed Android action router. Require confirmation for sensitive actions.
8. Build and sign a release APK; publish the web site and APK as separate artifacts.
