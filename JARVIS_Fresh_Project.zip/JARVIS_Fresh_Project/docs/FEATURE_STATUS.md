# Feature status

| Feature | Status | Notes |
|---|---|---|
| Premium responsive web UI | Implemented | Static HTML/CSS/JS |
| Detailed Arc Reactor artwork | Implemented | CSS-drawn, web; Canvas-drawn, Android |
| Web chat history | Implemented locally | Local storage; demo response engine |
| Web memory notes | Implemented locally | Add, search, delete |
| Browser speech input | Partial | Push-to-talk only; browser support varies |
| Browser text-to-speech | Implemented where supported | Uses device/browser voices |
| Native Android overlay | Implemented foundation | Requires user permission |
| Drag and edge snap | Implemented | Android service |
| Overlay popup controls | Implemented | Android service |
| Media volume buttons | Implemented | Android AudioManager |
| Large dimmed reactor | Implemented | Tap popup → Show Reactor |
| Back-button minimization | Limited | Explicit minimize/close control provided; system Back dispatch depends on overlay focus and Android version |
| Background wake-word | Not implemented | Requires a licensed on-device engine and microphone foreground service |
| Cloud AI | Not implemented | Secure backend required |
| Firebase sync/auth | Not implemented | Configure separately |
| Windows companion | Not implemented | Separate project |
| Signed APK | Not included | Build/sign in Android Studio |
