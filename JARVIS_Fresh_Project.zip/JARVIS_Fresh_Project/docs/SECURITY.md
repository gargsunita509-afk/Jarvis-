# Security and privacy

- The web project stores demo conversations and memory notes in the current browser's local storage. They are not cloud-synced.
- Browser speech recognition may use browser/platform speech services. Review your browser's privacy controls before enabling it.
- The Android overlay requires explicit "Display over other apps" approval.
- The Android foreground service displays an ongoing notification and has a visible stop action.
- This version does not access the Android microphone and does not run wake-word detection.
- Do not add private AI keys to `web/app.js`, HTML, CSS, or any public repository.
- For cloud AI, use a server-side endpoint and keep credentials in server environment variables.
- For Firebase, enforce per-user ownership in Firestore Security Rules; never rely only on client-side filtering.
- Do not add Accessibility Service automation without clear disclosure, narrow purpose, explicit user activation, and compliance with Android/Google Play policies.
