package com.jarvis.assistant

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.min

class ReactorView(context: Context, private val compact: Boolean = false) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = min(width, height) * if (compact) 0.46f else 0.43f

        // Soft energy halo.
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, radius * 1.15f,
            intArrayOf(0x553DEBFF, 0x223DEBFF, Color.TRANSPARENT),
            null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, radius * 1.15f, paint)
        paint.shader = null

        // Outer segmented titanium ring.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = radius * 0.075f
        paint.color = 0xFF9BAFB6.toInt()
        rect.set(cx-radius*0.91f, cy-radius*0.91f, cx+radius*0.91f, cy+radius*0.91f)
        canvas.drawArc(rect, 0f, 360f, false, paint)

        paint.strokeWidth = radius * 0.035f
        paint.color = 0xFF405A64.toInt()
        rect.set(cx-radius*0.99f, cy-radius*0.99f, cx+radius*0.99f, cy+radius*0.99f)
        canvas.drawArc(rect, 8f, 344f, false, paint)

        // Mechanical radial segments.
        paint.strokeWidth = radius * 0.09f
        paint.strokeCap = Paint.Cap.SQUARE
        for (i in 0 until 12) {
            val start = i * 30f + 3f
            paint.color = if (i % 2 == 0) 0xFFDBE7E9.toInt() else 0xFF526B74.toInt()
            rect.set(cx-radius*0.87f, cy-radius*0.87f, cx+radius*0.87f, cy+radius*0.87f)
            canvas.drawArc(rect, start, 13f, false, paint)
        }

        // Inner double ring.
        paint.strokeCap = Paint.Cap.BUTT
        paint.strokeWidth = radius * 0.055f
        paint.color = 0xFFB7E6E9.toInt()
        rect.set(cx-radius*0.66f, cy-radius*0.66f, cx+radius*0.66f, cy+radius*0.66f)
        canvas.drawCircle(cx, cy, radius*0.66f, paint)
        paint.strokeWidth = radius * 0.025f
        paint.color = 0xFF4BC9DC.toInt()
        canvas.drawCircle(cx, cy, radius*0.55f, paint)

        // Central luminous reactor core.
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx-radius*0.08f, cy-radius*0.1f, radius*0.39f,
            intArrayOf(Color.WHITE, 0xFFB9F8FF.toInt(), 0xFF38CBE8.toInt(), 0xFF0B526B.toInt()),
            floatArrayOf(0f, 0.28f, 0.68f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, radius*0.38f, paint)
        paint.shader = null
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, radius*0.10f, paint)
        paint.color = 0x885CEBFF.toInt()
        paint.strokeWidth = radius*0.035f
        paint.style = Paint.Style.STROKE
        canvas.drawCircle(cx, cy, radius*0.43f, paint)
        paint.style = Paint.Style.FILL
    }
}
