package com.jarvis.assistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class FloatingReactorService : Service() {
    companion object {
        const val ACTION_START = "com.jarvis.assistant.START"
        const val ACTION_SHOW_REACTOR = "com.jarvis.assistant.SHOW_REACTOR"
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        private const val CHANNEL = "jarvis_overlay_status"
        private const val NOTIFICATION_ID = 710
    }

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private var bubble: View? = null
    private var menu: View? = null
    private var expanded: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification())
        if (android.provider.Settings.canDrawOverlays(this)) showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_SHOW_REACTOR -> showExpanded()
            else -> if (android.provider.Settings.canDrawOverlays(this)) showBubble()
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "JARVIS floating assistant", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 2, Intent(this, FloatingReactorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val content = openIntent?.let {
            PendingIntent.getActivity(this, 1, it, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        }
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("JARVIS floating reactor is on")
            .setContentText("Tap the reactor for controls. Wake-word detection is not enabled.")
            .setOngoing(true)
            .setContentIntent(content)
            .addAction(android.R.drawable.ic_media_pause, "Turn off", stopIntent)
            .build()
    }

    private fun showBubble() {
        if (bubble != null || !android.provider.Settings.canDrawOverlays(this)) return
        val reactor = ReactorView(this, compact = true)
        val p = WindowManager.LayoutParams(
            dp(68), dp(68), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(220) }
        bubbleParams = p
        var downX = 0f; var downY = 0f; var originX = 0; var originY = 0; var moved = false
        reactor.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX=e.rawX; downY=e.rawY; originX=p.x; originY=p.y; moved=false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx=(e.rawX-downX).toInt(); val dy=(e.rawY-downY).toInt()
                    if (abs(dx)+abs(dy)>10) moved=true
                    p.x=originX+dx; p.y=originY+dy
                    try { wm.updateViewLayout(reactor,p) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) showMenu()
                    else {
                        val screen=resources.displayMetrics.widthPixels
                        p.x=if (p.x+dp(34)<screen/2) dp(4) else screen-dp(72)
                        try { wm.updateViewLayout(reactor,p) } catch (_: Exception) {}
                    }
                    true
                }
                else -> false
            }
        }
        bubble=reactor
        wm.addView(reactor,p)
    }

    private fun showMenu() {
        removeMenu()
        val panel=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(14),dp(10),dp(14),dp(10))
            background=GradientDrawable().apply {
                cornerRadius=dp(18).toFloat()
                setColor(0xF0182932.toInt())
                setStroke(dp(1),0xFF69DCE8.toInt())
            }
            addView(menuItem("OPEN JARVIS") { openApp() })
            addView(menuItem("SHOW LARGE REACTOR") { showExpanded() })
            addView(menuItem("VOLUME −") { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_LOWER,0) })
            addView(menuItem("VOLUME +") { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_RAISE,0) })
            addView(menuItem("TURN JARVIS OFF") { stopSelf() })
        }
        val p=WindowManager.LayoutParams(
            dp(220),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity=Gravity.TOP or Gravity.END; x=dp(12); y=(bubbleParams?.y ?: dp(220)) }
        menu=panel
        wm.addView(panel,p)
    }

    private fun menuItem(label: String, action: () -> Unit): TextView =
        TextView(this).apply {
            text=label; textSize=12f; setTextColor(0xFFE5F8FA.toInt())
            setPadding(dp(9),dp(14),dp(9),dp(14))
            setOnClickListener { removeMenu(); action() }
        }

    private fun showExpanded() {
        removeMenu(); removeExpanded()
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            gravity=Gravity.CENTER
            setBackgroundColor(0x80000000.toInt()) // 50% black dim layer
        }
        val reactor=ReactorView(this)
        val reactorSize=(resources.displayMetrics.widthPixels*0.55f).toInt()
        root.addView(reactor,LinearLayout.LayoutParams(reactorSize,reactorSize))
        val label=TextView(this).apply {
            text="J.A.R.V.I.S.  •  READY"
            textSize=12f; setTextColor(Color.WHITE); gravity=Gravity.CENTER
            setPadding(0,dp(18),0,dp(12))
        }
        root.addView(label)
        val minimize=TextView(this).apply {
            text="MINIMIZE  ×"
            textSize=12f; setTextColor(0xFFBDF7FA.toInt()); gravity=Gravity.CENTER
            setPadding(dp(24),dp(12),dp(24),dp(12))
            background=GradientDrawable().apply { cornerRadius=dp(24).toFloat(); setColor(0xCC102A34.toInt()); setStroke(dp(1),0xFF60D6E3.toInt()) }
            setOnClickListener { removeExpanded() }
        }
        root.addView(minimize)
        val p=WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity=Gravity.CENTER }
        expanded=root
        wm.addView(root,p)
    }

    private fun removeMenu() {
        menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        menu=null
    }
    private fun removeExpanded() {
        expanded?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        expanded=null
    }
    private fun openApp() {
        packageManager.getLaunchIntentForPackage(packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { startActivity(it) }
    }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        removeMenu(); removeExpanded()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble=null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
