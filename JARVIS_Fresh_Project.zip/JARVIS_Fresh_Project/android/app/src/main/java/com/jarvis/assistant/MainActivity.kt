package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.view.Gravity
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val requestCodeNotifications = 500

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
            setBackgroundColor(Color.rgb(8, 13, 19))
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 30f
            setTextColor(Color.rgb(190, 245, 250))
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Native Android companion\\n\\nEnable the floating mechanical Arc Reactor. Android will ask you to allow display over other apps. The service shows a persistent notification while active.\\n\\nWake-word detection and AI are not connected in this release."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val enable = Button(this).apply {
            text = "ENABLE FLOATING REACTOR"
            setOnClickListener { enableOverlay() }
        }
        val show = Button(this).apply {
            text = "SHOW LARGE REACTOR"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startServiceAction(FloatingReactorService.ACTION_SHOW_REACTOR)
                } else {
                    Toast.makeText(this@MainActivity, "Grant overlay permission first.", Toast.LENGTH_LONG).show()
                }
            }
        }
        val stop = Button(this).apply {
            text = "TURN JARVIS OFF"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingReactorService::class.java)) }
        }
        layout.addView(title)
        layout.addView(description)
        layout.addView(enable)
        layout.addView(show)
        layout.addView(stop)
        setContentView(layout)
        if (intent?.action == FloatingReactorService.ACTION_SHOW_REACTOR) {
            if (Settings.canDrawOverlays(this)) startServiceAction(FloatingReactorService.ACTION_SHOW_REACTOR)
        }
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "Allow JARVIS to display over other apps, then return and tap Enable again.", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestCodeNotifications)
            return
        }
        startServiceAction(FloatingReactorService.ACTION_START)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestCodeNotifications && Settings.canDrawOverlays(this)) {
            startServiceAction(FloatingReactorService.ACTION_START)
        }
    }

    private fun startServiceAction(action: String) {
        val intent = Intent(this, FloatingReactorService::class.java).setAction(action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }
}
