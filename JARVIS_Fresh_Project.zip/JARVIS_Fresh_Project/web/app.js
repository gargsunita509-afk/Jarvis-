(() => {
  const $ = (id) => document.getElementById(id);
  const keys = { chat: 'jarvis_fresh_chat_v1', memories: 'jarvis_fresh_memories_v1', settings: 'jarvis_fresh_settings_v1' };
  const safeRead = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
  const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));
  let chat = safeRead(keys.chat, [{role:'jarvis', text:'JARVIS interface initialized. I can store local notes and demonstrate the interface. Connect a secure AI backend for real intelligent responses.'}]);
  let memories = safeRead(keys.memories, []);
  let settings = safeRead(keys.settings, { speech:true, rate:1, enabled:true });
  let toastTimer;
  const toast = (message) => { const el=$('toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),2400); };
  const escapeHtml = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function navigate(view) {
    document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id===`view-${view}`));
    document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.view===view));
    window.scrollTo({top:0,behavior:'smooth'});
  }
  document.querySelectorAll('.nav').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.view)));
  document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.go)));
  $('settingsJump').addEventListener('click',()=>navigate('settings'));

  function renderChat() {
    $('chatMessages').innerHTML = chat.map(m=>`<div class="bubble-msg ${m.role==='user'?'user':''}"><div class="avatar">${m.role==='user'?'YOU':'✧'}</div><div class="msg-content">${escapeHtml(m.text)}</div></div>`).join('');
    $('chatMessages').scrollTop=$('chatMessages').scrollHeight;
  }
  function addMessage(role,text) { chat.push({role,text}); save(keys.chat,chat); renderChat(); }
  function replyFor(text) {
    const t=text.toLowerCase();
    if (t.includes('memory') || t.includes('remember')) return 'I can save personal notes in the Memory Centre on this browser. I do not yet have cloud memory or cross-device synchronization.';
    if (t.includes('time')) return `Your device reports ${new Date().toLocaleTimeString()}.`;
    if (t.includes('date')) return `Today is ${new Date().toLocaleDateString()}.`;
    if (t.includes('hello') || t.includes('hi')) return 'Hello. JARVIS local interface is online. The AI backend is not connected yet.';
    if (t.includes('open youtube')) return 'This web console cannot control other phone apps. Use the native Android companion for supported device actions.';
    return 'This is a local demo response, not an AI-generated answer. Connect a secure AI backend to enable real reasoning and device-aware assistance.';
  }
  function send(inputId) {
    const input=$(inputId), text=input.value.trim(); if(!text)return;
    addMessage('user',text); input.value='';
    const answer=replyFor(text); addMessage('jarvis',answer); speak(answer);
  }
  $('chatSend').addEventListener('click',()=>send('chatInput'));
  $('chatInput').addEventListener('keydown',e=>{if(e.key==='Enter')send('chatInput')});
  $('quickSend').addEventListener('click',()=>{const v=$('quickInput').value.trim();if(v){navigate('conversation');$('chatInput').value=v;send('chatInput');$('quickInput').value='';}});
  $('quickInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('quickSend').click()});
  $('clearChat').addEventListener('click',()=>{if(confirm('Clear this browser conversation history?')){chat=[];save(keys.chat,chat);renderChat();toast('Conversation cleared.')}});

  function renderMemories() {
    const query=$('memorySearch').value.trim().toLowerCase();
    const filtered=memories.filter(m=>m.text.toLowerCase().includes(query));
    $('memoryCount').textContent=`${memories.length} saved notes`;
    $('memoryCountLarge').textContent=`${memories.length} notes`;
    $('memoryList').innerHTML=filtered.length?filtered.map(m=>`<div class="memory-item"><span>${escapeHtml(m.text)}</span><button data-delete="${m.id}">DELETE</button></div>`).join(''):'<div class="empty">No matching notes. Add a note above to start your local memory.</div>';
    $('memoryList').querySelectorAll('[data-delete]').forEach(b=>b.addEventListener('click',()=>{memories=memories.filter(m=>m.id!==b.dataset.delete);save(keys.memories,memories);renderMemories();toast('Memory note deleted.');}));
  }
  $('addMemory').addEventListener('click',()=>{const text=$('memoryInput').value.trim();if(!text)return;memories.unshift({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),text,createdAt:new Date().toISOString()});save(keys.memories,memories);$('memoryInput').value='';renderMemories();toast('Saved in this browser.');});
  $('memoryInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('addMemory').click()});
  $('memorySearch').addEventListener('input',renderMemories);

  function speak(text) {
    if(!settings.speech || !('speechSynthesis' in window))return;
    window.speechSynthesis.cancel();
    const utterance=new SpeechSynthesisUtterance(text); utterance.rate=Number(settings.rate)||1;
    window.speechSynthesis.speak(utterance);
  }
  $('voiceTest').addEventListener('click',()=>{if(!('speechSynthesis' in window)){toast('Speech synthesis is not supported in this browser.');return;}speak('JARVIS voice output test.');toast('Speaking test response.');});
  $('speechToggle').checked=!!settings.speech;
  $('speechRate').value=settings.rate||1;
  $('speechToggle').addEventListener('change',e=>{settings.speech=e.target.checked;save(keys.settings,settings);});
  $('speechRate').addEventListener('input',e=>{settings.rate=Number(e.target.value);save(keys.settings,settings);});
  $('toggleAssistant').addEventListener('click',()=>{settings.enabled=!settings.enabled;save(keys.settings,settings);updateStatus();toast(settings.enabled?'Web interface enabled.':'Web interface paused.');});
  function updateStatus(){ $('assistantStatus').textContent=settings.enabled?'Ready for activation':'Paused';$('coreStatus').textContent=settings.enabled?'CORE STANDBY':'CORE OFFLINE';$('systemState').textContent=settings.enabled?'WEB CONSOLE READY':'INTERFACE PAUSED';$('toggleAssistant').innerHTML=settings.enabled?'<span>⏻</span> TURN OFF':'<span>⏻</span> TURN ON';$('toggleAssistant').classList.toggle('off',!settings.enabled); }
  $('deleteData').addEventListener('click',()=>{if(confirm('Delete all JARVIS local conversations, memory notes and settings from this browser?')){localStorage.removeItem(keys.chat);localStorage.removeItem(keys.memories);localStorage.removeItem(keys.settings);chat=[];memories=[];settings={speech:true,rate:1,enabled:true};renderChat();renderMemories();$('speechToggle').checked=true;$('speechRate').value=1;updateStatus();toast('Local JARVIS data deleted.');}});
  function startSpeech(target) {
    const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SpeechRecognition){toast('Speech recognition is not supported here. Try a supported browser.');return;}
    const recognition=new SpeechRecognition();recognition.lang='en-IN';recognition.interimResults=false;recognition.maxAlternatives=1;
    $('voiceStatus').textContent='Listening…';
    recognition.onresult=e=>{const transcript=e.results[0][0].transcript;$(target).value=transcript;if(target==='chatInput')send(target);else{$('quickInput').value=transcript;$('quickSend').click();}};
    recognition.onerror=e=>toast(`Speech input error: ${e.error}`);
    recognition.onend=()=>{$('voiceStatus').textContent='Ready';};
    try{recognition.start();}catch{toast('Could not start microphone. Check browser permission.');}
  }
  $('quickMic').addEventListener('click',()=>startSpeech('quickInput'));
  $('chatMic').addEventListener('click',()=>startSpeech('chatInput'));
  renderChat();renderMemories();updateStatus();
})();
