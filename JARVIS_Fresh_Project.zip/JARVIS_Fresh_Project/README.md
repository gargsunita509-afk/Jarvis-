# J.A.R.V.I.S. — Fresh Project

A fresh, editable JARVIS project with two separate parts:

1. **Web console** — deployable static website with a premium Arc Reactor interface, local conversation history, local memory notes, settings, and browser speech controls where supported.
2. **Native Android companion** — Kotlin Android project with a real system overlay foundation: draggable mechanical Arc Reactor bubble, edge snapping, popup actions, media volume controls, open-app action, and a larger dimmed reactor overlay.

This is an honest, usable foundation—not a claim that every science-fiction capability is already complete.

## What works now

### Web
- Responsive futuristic dashboard.
- Detailed CSS-drawn mechanical Arc Reactor (not a generic blue circle).
- Local conversation history and memory notes saved in browser local storage.
- Memory add/search/delete.
- Browser speech recognition and speech synthesis when the browser supports them and the user grants microphone permission.
- Local demo responses clearly identified as demo responses.
- Settings for voice response and interface sound.
- Static build: no npm dependencies required.

### Android
- Native Kotlin project.
- User-granted draw-over-other-apps permission.
- Foreground service started from the visible app.
- Floating Arc Reactor drawn by custom Android Canvas graphics.
- Dragging and left/right edge snapping.
- Popup with Open JARVIS, Show Reactor, Volume Down, Volume Up, and Turn Off.
- Large centered reactor overlay with a 50% dim background.
- Explicit close/minimize control.
- Service notification with a Stop action.

## Not yet implemented (do not assume otherwise)
- Always-on "Jarvis" wake-word detection.
- Gemini/other cloud AI backend.
- Firebase authentication, cloud memory sync, and account system.
- Automatic control of every Android app.
- Windows companion.
- Signed release APK.

The web voice button is **push-to-talk using browser speech APIs**; it is not an always-on background wake-word engine. The Android overlay currently opens by tapping the floating bubble and selecting **Show Reactor**. A real on-device wake-word engine must be integrated and tested separately before voice-triggered overlay activation can be claimed.

## Web: run locally

No Node.js is needed.

- Open `web/index.html` in a modern browser, or
- Use any static server, or
- Deploy `web/` to Netlify.

### Netlify settings
- Base directory: `web`
- Build command: leave empty
- Publish directory: `.`

If Netlify requires a build command, use `echo "Static JARVIS site"`.

For GitHub:
1. Extract this ZIP.
2. Create a new GitHub repository.
3. Upload the **contents** of the extracted folder (including `web/`, `android/`, and `docs/`), not just the ZIP.
4. Connect the repository to Netlify with the settings above.

## Android: build

1. Install Android Studio on a computer.
2. Open the `android/` folder.
3. Allow Gradle sync and install the Android SDK requested by Android Studio.
4. Run on a physical Android phone.
5. Open JARVIS and tap **Enable Floating Reactor**.
6. Grant the Android "Display over other apps" permission.
7. Return to JARVIS and enable the floating reactor.
8. Tap the floating reactor and test its popup.

The Android project includes Gradle build files but not a Gradle wrapper JAR or Android SDK. Android Studio will set up the build environment.

### Android version and store note
The overlay uses Android's special-use foreground-service category because it maintains a user-visible floating assistant control. Newer Android versions and app stores impose restrictions and review requirements on special-use foreground services. Sideload testing and Play Store distribution are not the same approval process. Review current Android policy before public distribution.

## Editing later

- Edit web files in GitHub or a code editor; commit changes to redeploy the site.
- Edit Android Kotlin files in Android Studio; build a new APK after changes.
- Keep `web/` and `android/` in the same repository, but deploy/build them separately.
- Never commit API keys, Firebase service-account files, signing keystores, or passwords.

## Folder map

```text
JARVIS_Fresh_Project/
├── web/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── android/
│   ├── settings.gradle.kts
│   ├── build.gradle.kts
│   ├── gradle.properties
│   └── app/
│       └── src/main/
│           ├── AndroidManifest.xml
│           └── java/com/jarvis/assistant/
│               ├── MainActivity.kt
│               ├── FloatingReactorService.kt
│               └── ReactorView.kt
└── docs/
    ├── FEATURE_STATUS.md
    ├── SECURITY.md
    └── ROADMAP.md
```
